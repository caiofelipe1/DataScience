import streamlit as st

# Configuração da página
st.set_page_config(page_title="Meu Dashboard", layout="wide")

# Menu lateral
st.sidebar.title("Navegação")
aba = st.sidebar.radio(
    "Selecione uma página:",
    ["Home", "Quem sou eu", "Minhas Skills", "Certificações / Análises"]
)

# Conteúdo de cada aba
if aba == "Home":
    st.title("Dashboard - Meu Currículo Interativo")
    st.markdown("Bem-vindo(a) ao meu dashboard! Aqui você encontra minhas informações profissionais, habilidades e certificações.")

elif aba == "Quem sou eu":
    st.title("Quem sou eu")
    st.markdown("Aqui vai o seu texto de apresentação...")

elif aba == "Minhas Skills":
    st.title("Minhas Skills")
    st.markdown("- Python\n- Análise de Dados\n- Machine Learning")

elif aba == "Certificações / Análises":
    st.title("Certificações / Análises")
    st.markdown("Lista de certificações e/ou resultados de análises...")
